from setuptools import setup

setup(
    name='logsimple',
    version='0.1.2',
    scripts=['logger.py']
)