from setuptools import setup

setup(
    name='logsimple',
    version='0.1.3',
    scripts=['logger.py']
)