from setuptools import setup

setup(
    name='logsimple',
    version='0.1.1',
    scripts=['logger.py']
)